export interface Todo {
  name: string;
  done: boolean;
}
