import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'todolist-filter',
  templateUrl: 'todolist-filter.component.html'
})
export class TodoListFilterComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}
