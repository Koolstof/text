import { Routes } from '@angular/router';
import { TodoListContainerComponent } from './todolist-container.component';

export const TODO_ROUTES: Routes = [{
  path: '',
  component: TodoListContainerComponent
}];
