import { FormArray, FormControl, Validators } from '@angular/forms';
import { AuthorizedParticipantMainInfo } from './authorized-participant-main-info.model';

export class AuthorizedParticipantMainInfoForm {
  type = new FormControl('', Validators.required);
  name = new FormControl('', Validators.required);
  settlementContacts = new FormArray([]);

  constructor(authorizedParticipantMainInfo?: AuthorizedParticipantMainInfo) {
    if(authorizedParticipantMainInfo) {
      this.type.setValue(authorizedParticipantMainInfo.type);
      this.name.setValue(authorizedParticipantMainInfo.name);
      this.settlementContacts.setValue(authorizedParticipantMainInfo.settlementContacts);
    }
  }
}
