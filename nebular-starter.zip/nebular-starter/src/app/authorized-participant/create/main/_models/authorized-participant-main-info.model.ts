import { SettlementContact } from '../settlement-contact/_models/settlement-contact.model';


export class AuthorizedParticipantMainInfo {
  type: string;
  name: string;
  settlementContacts: Array<SettlementContact>;
}
