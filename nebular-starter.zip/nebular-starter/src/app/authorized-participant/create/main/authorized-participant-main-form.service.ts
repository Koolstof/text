import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { AuthorizedParticipantMainInfoForm } from './_models/authorized-participant-main-info-form.model';
import { SettlementContactForm } from './settlement-contact/_models/settlement-contact-form.model';
import { AuthorizedParticipantMainInfo } from './_models/authorized-participant-main-info.model';

@Injectable()
export class AuthorizedParticipantMainFormService {
  private mainInformationForm: BehaviorSubject<FormGroup> = new BehaviorSubject(
    this.fb.group(new AuthorizedParticipantMainInfoForm())
  );

  mainInformationForm$ = this.mainInformationForm.asObservable();

  constructor(private fb: FormBuilder) {
  }

  resetForm() {
    this.mainInformationForm.value.reset();
    const settlementContactsFormArray = this.mainInformationForm.value.get('settlementContacts') as FormArray;
    settlementContactsFormArray.clear();
    this.mainInformationForm.next(this.mainInformationForm.getValue());
  }

  patch({type, name, settlementContacts}: AuthorizedParticipantMainInfo) {
    const currentForm = this.mainInformationForm.getValue();
    const settlementContactsFormArray = currentForm.get('settlementContacts') as FormArray;
    currentForm.patchValue({type, name});

    settlementContacts.map(contact => this.fb.group(new SettlementContactForm(contact))).forEach(formGroup => {
      settlementContactsFormArray.push(formGroup);
    });

    this.mainInformationForm.next(this.mainInformationForm.getValue());
  }

  addSettlementContact() {
    const currentForm = this.mainInformationForm.getValue();
    const settlementContacts = currentForm.get('settlementContacts') as FormArray;

    settlementContacts.push(this.fb.group(new SettlementContactForm()));
    this.mainInformationForm.next(currentForm);
  }

  deleteSettlmentContact(index: number) {
    const currentForm = this.mainInformationForm.getValue();
    const settlementContacts = currentForm.get('settlementContacts') as FormArray;

    settlementContacts.removeAt(index);
    this.mainInformationForm.next(currentForm);
  }
}
