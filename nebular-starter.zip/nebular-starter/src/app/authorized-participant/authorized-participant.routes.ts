import { Routes } from '@angular/router';
import { AuthorizedParticipantListComponent } from './list/authorized-participant-list.component';
import { AuthorizedParticipantDetailComponent } from './detail/authorized-participant-detail.component';
import { ApDetailUserGroupComponent } from './detail/user-group/ap-detail-user-group.component';
import { AuthorizedParticipantCreateComponent } from './create/authorized-participant-create.component';
import { AuthorizedParticipantDetailMainComponent } from './detail/main/authorized-participant-detail-main.component';
import { AuthorizedParticipantMainResolver } from './detail/main/authorized-participant-main.resolver';

export const AP_ROUTES: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: AuthorizedParticipantListComponent
  },
  {
    path: 'create',
    component: AuthorizedParticipantCreateComponent
  },
  {
    path: ':authorizedParticipantId',
    component: AuthorizedParticipantDetailComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'main'
      },
      {
        path: 'main',
        component: AuthorizedParticipantDetailMainComponent,
        resolve: { main: AuthorizedParticipantMainResolver }
      },
      {
        path: 'user-group',
        component: ApDetailUserGroupComponent
      }]
  }
];
