import { FormGroup } from '@angular/forms';

export class AuthorizedParticipantForm {
  mainInformation = new FormGroup({});
}
