import { NgModule } from '@angular/core';
import { AuthorizedParticipantListComponent } from './authorized-participant-list.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [AuthorizedParticipantListComponent],
  declarations: [AuthorizedParticipantListComponent],
  providers: [],
})
export class AuthorizedParticipantListModule {
}
