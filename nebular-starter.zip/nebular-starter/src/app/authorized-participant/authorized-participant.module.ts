import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AP_ROUTES } from './authorized-participant.routes';
import { AuthorizedParticipantDetailModule } from './detail/authorized-participant-detail.module';
import { AuthorizedParticipantListModule } from './list/authorized-participant-list.module';
import { AuthorizedParticipantCreateModule } from './create/authorized-participant-create.module';
import { AuthorizedParticipantMainResolver } from './detail/main/authorized-participant-main.resolver';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AP_ROUTES),
    AuthorizedParticipantListModule,
    AuthorizedParticipantDetailModule,
    AuthorizedParticipantCreateModule
  ],
  providers: [

  ],
})
export class AuthorizedParticipantModule {
}
