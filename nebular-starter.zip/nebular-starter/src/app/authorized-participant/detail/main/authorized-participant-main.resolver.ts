import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { AuthorizedParticipantMainInfo } from '../../create/main/_models/authorized-participant-main-info.model';
import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthorizedParticipantMainResolver implements Resolve<AuthorizedParticipantMainInfo> {

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<AuthorizedParticipantMainInfo> {
    return of({
      type: 'ETF',
      name: 'Auth. Participan To Edit ....',
      settlementContacts: [
        {
          name: 'sett. contact 1',
          email: 'contact1@gmail.com',
          phone: '+ 01021245213'
        },
        {
          name: 'sett. contact 2',
          email: 'contact2@yahoo.com',
          phone: '+ 01021999856'
        }
      ]
    });
  }

}
