import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ap-detail-user-group',
  template: 'ap-detail-user-group-component.component.html'
})

export class ApDetailUserGroupComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}
