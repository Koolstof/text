import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'authorized-participants',
    pathMatch: 'full'
  },
  {
    path: 'todolist',
    loadChildren: () => import('./todolist/todolist-container.module').then(m => m.TodoListContainerModule)
  },
  {
    path: 'authorized-participants',
    loadChildren: () => import('./authorized-participant/authorized-participant.module').then(m => m.AuthorizedParticipantModule)
  },
  { path: '**', redirectTo: 'authorized-participants' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing: false, useHash: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
